package com.example.luisjv.contaccall;

/**
 * Clase Contacto
 */
public class Contacto {

    private String name;
    private String tel;
    private int img;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTel() {
        return tel;
    }

    public void setPos(String pos) {
        this.tel = pos;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
